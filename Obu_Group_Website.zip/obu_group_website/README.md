# Obu Group Website

Features: public web login, member read-only dashboard, Admin Anoxx add/edit/delete controls, money totals and search.

Demo admin: anoxx / ChangeMe123!
Demo member: member / Member123!

For real Internet deployment, change passwords and SESSION_SECRET, use HTTPS, hashed passwords and a production database.

Run: npm install && npm start, then open http://localhost:3000 in Chrome.
